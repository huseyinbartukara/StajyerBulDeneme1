package com.example.stajyerbuldeneme1.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.stajyerbuldeneme1.R
import com.example.stajyerbuldeneme1.databinding.FragmentKayitOlBinding
import com.example.stajyerbuldeneme1.databinding.FragmentKayitOlSirketBinding

class KayitOlSirketFragment : Fragment() {

    private lateinit var tasarim : FragmentKayitOlSirketBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = FragmentKayitOlSirketBinding.inflate(inflater,container,false)
        val view = tasarim.root

        tasarim.buttonKaydol.setOnClickListener {
            kayitOlSirketButton(it)
        }


        return view
    }

    fun kayitOlSirketButton(it:View){
        Navigation.findNavController(it).navigate(R.id.girisYapFragmentGecisSirket)
    }
}