package com.example.stajyerbuldeneme1.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.stajyerbuldeneme1.R
import com.example.stajyerbuldeneme1.databinding.FragmentKayitOlBinding
import com.example.stajyerbuldeneme1.databinding.FragmentSplashBinding

class SplashFragment : Fragment() {

    private lateinit var tasarim : FragmentSplashBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = FragmentSplashBinding.inflate(inflater,container,false)
        val view = tasarim.root



        Handler(Looper.myLooper()!!).postDelayed({
            findNavController().navigate(R.id.splashScreenGecis)

        },3000)



        return view

    }
}