package com.example.stajyerbuldeneme1.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.stajyerbuldeneme1.R
import com.example.stajyerbuldeneme1.databinding.FragmentGirisYapBinding

class GirisYapFragment : Fragment() {

    private lateinit var tasarim : FragmentGirisYapBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = FragmentGirisYapBinding.inflate(inflater,container,false)
        val view = tasarim.root



        tasarim.textViewKaydol.setOnClickListener {
            kayitOlText(it)
        }

        tasarim.textViewKaydolSirket.setOnClickListener {
            kayitOlSirketText(it)
        }


        return view
    }


    fun kayitOlText(it:View){
        Navigation.findNavController(it).navigate(R.id.kayitOlFragmentGecis)
    }

    fun kayitOlSirketText(it:View){
        Navigation.findNavController(it).navigate(R.id.kayitOlSirketFragmentGecis)
    }


}