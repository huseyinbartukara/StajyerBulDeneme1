package com.example.stajyerbuldeneme1.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.stajyerbuldeneme1.R
import com.example.stajyerbuldeneme1.databinding.FragmentGirisYapBinding
import com.example.stajyerbuldeneme1.databinding.FragmentKayitOlBinding

class KayitOlFragment : Fragment() {

    private lateinit var tasarim : FragmentKayitOlBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        tasarim = FragmentKayitOlBinding.inflate(inflater,container,false)
        val view = tasarim.root


        tasarim.buttonKaydol.setOnClickListener {
            kayıtOlButton(it)
        }








        return view
    }

    fun kayıtOlButton(it:View){
        Navigation.findNavController(it).navigate(R.id.girisYapFragmentGecis)
    }




}